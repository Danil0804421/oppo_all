from Date import Data

class RealEstate:
    def __init__(self, owner, data, estimatedValue: list) -> None:
        self.owner = self.validate_owner(owner)
        self.registrationDate = Data(data)
        self.estimatedValue = self.validate_estimated_value(estimatedValue)

    def validate_owner(self, owner):
        """ Проверяем, состоит ли имя из двух слов """
        if len(owner.split()) == 2:
            return owner
        else:
            raise ValueError("Поле 'owner' должно состоять из двух слов")

    def validate_estimated_value(self, estimated_value):
        if any(value < 0 for value in estimated_value):
            raise ValueError("Поле 'estimatedValue' не должно содержать отрицательные значения")
        if max(estimated_value) > 50000000:
            raise ValueError("Поле 'estimatedValue' не должно превышать 50000000")
        return estimated_value
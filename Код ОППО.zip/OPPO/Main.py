"""Здравствуйте, так как я ни разу не оформлял отчет по вашему предмету, решил,
что можно будет расставиить комментарии каждой строке,
к которой у преподавателя могут возникнуть вопросы ко мне."""

import cProfile
from RealEstate import RealEstate

def __doc__():
    return "Главная программа проекта"


def file_operations() -> list:
    """Чтение файла и запись данных в массив"""
    properties = []
    try:
        with open('data', 'r') as file:
            for line in file:
                data = line.split(',')
                owner = data[0]
                date = data[1]
                value = [int(data[2])]
                properties.append(RealEstate(owner, date, value))
    except FileNotFoundError:
        print("Файл не найден")
    return properties


def information(propertyObjects: list) -> None:
    """Вывод информации на консоль"""
    for property in propertyObjects:
        print("Владелец:", property.owner)
        print("Дата постановки на учет:", property.registrationDate)
        print("Ориентировочная стоимость:", property.estimatedValue)
        print()

information(file_operations())

"""Динамический анализ времени работы программы"""
cProfile.run('file_operations()')

